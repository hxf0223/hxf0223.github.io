#include <iostream>
#include <memory>

#include <boost/core/ignore_unused.hpp>

struct Immortal {
  std::shared_ptr<Immortal> self;

  ~Immortal() {
    std::cout << "dtor of Immortal called. self.use_count() = " << self.use_count() << std::endl;
    // self.reset(); // (1)
  }
};

int main(int argc, char* argv[]) {
  boost::ignore_unused(argc, argv);
  auto immortal = new Immortal();
  immortal->self = std::shared_ptr<Immortal>(immortal);
  std::cout << "main exit. immortal->self.use_count() = " << immortal->self.use_count() << std::endl;
  // delete immortal; (2)
  return 0;
}
